package com.infy.intervie.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest

class ProjectForInterviewPreparationApplicationTests {

	@Test
	void contextLoads() {
	}

}
