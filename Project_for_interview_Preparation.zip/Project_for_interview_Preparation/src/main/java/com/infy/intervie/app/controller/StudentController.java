package com.infy.intervie.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.intervie.app.ServiceImpl.StudentServiceImpl;
import com.infy.intervie.app.Services.StudentService;
import com.infy.intervie.app.exceptions.StudentNotFoundException;
import com.infy.intervie.app.model.Student;

//@RestController
@Component
@RequestMapping(value = "/api")
public class StudentController 
{
	@Autowired private StudentService service;
//	@Autowired private StudentServiceImpl service;

	@PostMapping(value = "/student")
	public ResponseEntity<Student> saveStudent(@Valid @RequestBody Student student) 
	{
		Student student2 = service.saveStudent(student);

		return new ResponseEntity<Student>(student2, HttpStatus.CREATED);
	}

	@GetMapping(value = "/student")
	public ResponseEntity<List<Student>> getAllStudents() {

		List<Student> listStudents = this.service.getAllStudent();
		
		
		
		return new ResponseEntity<List<Student>>(listStudents, HttpStatus.ACCEPTED);
	}

	@GetMapping(value = "/student/{id}")
	public ResponseEntity<Student> getSingleStudent(@PathVariable int id) 
	{

		Student sId = this.service.getSingleStudent(id);

		return new ResponseEntity<Student>(sId, HttpStatus.ACCEPTED);

	}

	@DeleteMapping(value = "/student/{id}")
	public ResponseEntity<String> deleteStudent(@PathVariable int id) 
	{	
		this.service.deleteStudentById(id);

		return new ResponseEntity<String>("Student deleted",HttpStatus.ACCEPTED);	
	}
	
	@PutMapping(value = "/student/{sid}")
	public ResponseEntity<Student> updateStudent(@RequestBody Student student, @PathVariable Integer sid)
	{
	
		Student student2 = this.service.updateStudent(student,sid);
		
		return new ResponseEntity<Student>(student2,HttpStatus.ACCEPTED);
		
	}
	
	@PatchMapping(value = "/student/{id}")
	public ResponseEntity<Student> updateName(@PathVariable int id, @RequestBody Student sname)
	{
//		Student student = this.service.updateName(id,sname);
		
		return new ResponseEntity<Student>(HttpStatus.ACCEPTED);
	}

	
	

}
