package com.infy.intervie.app.lookupMethod;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class SchoolNotification
{
	
}
