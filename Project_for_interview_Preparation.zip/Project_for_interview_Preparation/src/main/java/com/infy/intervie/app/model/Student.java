package com.infy.intervie.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int studentID;
	
	@NotNull(message = "Name is required")
	@Pattern(regexp = "^[a-z A-Z]{4,10}$", message = "first name Should be 4 to 10 , only alphabets allowed ")
	private String studentName;
	@NotNull
	@Size(min = 1, max = 3, message = "Age is Required")
	private String studentAge;
	
	@NotBlank(message = "Address is Required")
	private String studentAddress;
	
	

}
