 package com.infy.intervie.app.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(StudentNotFoundException.class)
	public ResponseEntity<String> studentNotFoundException(StudentNotFoundException e) {

		System.out.println("Handling the exception");

		String msg = e.getMessage();

		return new ResponseEntity<String>(msg, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> methodArgumentNotValidException(MethodArgumentNotValidException e) {
		System.out.println("Handler Method");

		Map<String, String> map = new HashMap<>();

		for (FieldError fe : e.getBindingResult().getFieldErrors())
		{
			map.put(fe.getDefaultMessage(), fe.getField());
		}

		return new ResponseEntity<>(map, HttpStatus.NOT_ACCEPTABLE);

	}
}
