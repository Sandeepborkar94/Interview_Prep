package com.infy.intervie.app.controller;

import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infy.intervie.app.Services.StudentService;
import com.infy.intervie.app.exceptions.StudentNotFoundException;
import com.infy.intervie.app.model.Student;

@RestController
public class StudentController1 
{
	@Autowired private StudentService service;
	
	@GetMapping(value = "/student")
	public ResponseEntity<List<Student>> getAllStudents() {

		List<Student> listStudents = this.service.getAllStudent();
		
//		Collections.sort((List<Student>) listStudents);
		
		

		if (listStudents == null) 
		{
			throw new StudentNotFoundException("List of Student Not Found");
		}
		
		return new ResponseEntity<List<Student>>(listStudents, HttpStatus.ACCEPTED);
	}
}
