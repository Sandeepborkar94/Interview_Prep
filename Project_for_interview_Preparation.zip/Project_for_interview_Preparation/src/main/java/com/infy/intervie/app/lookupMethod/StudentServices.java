package com.infy.intervie.app.lookupMethod;

import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

@Component
public class StudentServices
{
	@Lookup
	public SchoolNotification getNotification() 
	{
		return null;
	}
	
	
}
