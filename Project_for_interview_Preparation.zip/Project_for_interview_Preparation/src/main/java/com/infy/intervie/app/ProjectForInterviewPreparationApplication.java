package com.infy.intervie.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class ProjectForInterviewPreparationApplication
{
	
	@GetMapping(value = "/")
	public String home() 
	{
		return "WELCOME TO FIRST AWS DEPLOYEMENT";		
	}
	
	
	
	public static void main(String[] args) 
	{
		SpringApplication.run(ProjectForInterviewPreparationApplication.class, args);
		
		System.out.println("Sandeep Borkar");
		
		System.err.println("Application started");
	}
}
