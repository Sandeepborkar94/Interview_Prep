package com.infy.intervie.app.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.intervie.app.model.HelloWorldBean;

@RestController
@RequestMapping(value = "/api")
public class HelloWorldController
{
	@RequestMapping(method = RequestMethod.GET, path = "/get")
//	@GetMapping(value = "/get")
	public String helloWorld() 
	{
		return "Hello World";
	}

	@GetMapping(value = "/getBean")
	public HelloWorldBean helloWorldBean()
	{
		HelloWorldBean bean = new HelloWorldBean("Sandeep");

		return bean;

//		return new HelloWorldBean("Hello World Bean");
	}

	@GetMapping(value = "/get/path/{name}")
	public HelloWorldBean helloWorldBean1(@PathVariable String name) {
		return new HelloWorldBean(String.format("Hello World, %s", name));
	}
}
