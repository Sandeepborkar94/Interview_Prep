package com.infy.intervie.app.model;


public class HelloWorldBean
{
	public String message;

	public HelloWorldBean(String message) 
	{	
		this.message = message;
	}
}
