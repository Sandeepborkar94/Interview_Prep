package com.infy.intervie.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infy.intervie.app.model.Student;

@Repository
public interface StudentRepo extends JpaRepository<Student, Integer>
{
	public Student findByStudentID(int sid);
	
	public Student findByStudentName(String name);
	
}
