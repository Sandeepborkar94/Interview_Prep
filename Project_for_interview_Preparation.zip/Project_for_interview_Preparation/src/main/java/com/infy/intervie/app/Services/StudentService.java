package com.infy.intervie.app.Services;

import java.util.List;
import java.util.Set;

import com.infy.intervie.app.model.Student;

public interface StudentService 
{

	public Student saveStudent(Student student);

	public List<Student> getAllStudent();

	public Student getSingleStudent(int id);

	public void deleteStudentById(int id);

	public Student updateStudent(Student student, Integer sid);

	public List<Student> getAllStudent1(Student stu);

	

	

	
}
